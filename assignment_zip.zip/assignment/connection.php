<?php $sql=mysqli_connect('localhost','root','','art_store'); ?>
